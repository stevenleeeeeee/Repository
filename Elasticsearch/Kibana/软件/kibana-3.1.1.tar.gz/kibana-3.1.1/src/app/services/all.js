define([
  './alertSrv',
  './dashboard',
  './fields',
  './filterSrv',
  './kbnIndex',
  './querySrv',
  './timer',
  './panelMove',
  './esVersion'
],
function () {});