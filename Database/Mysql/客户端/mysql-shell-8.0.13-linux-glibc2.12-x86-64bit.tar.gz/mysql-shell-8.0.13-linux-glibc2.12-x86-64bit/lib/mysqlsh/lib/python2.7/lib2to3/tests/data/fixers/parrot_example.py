def parrot():
    pass
